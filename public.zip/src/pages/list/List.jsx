import React from 'react'
import UserList from '../../componets/UserList'

const List = () => {
  return (
    <div>
      //this is list page
      <UserList />
    </div>
  )
}

export default List